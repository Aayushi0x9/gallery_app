// import 'dart:io';
// import 'package:async_wallpaper/async_wallpaper.dart';
// import 'package:flutter/material.dart';
// import 'package:gallery_app/Views/ImagePage/image1_page.dart';
// import 'package:gallery_app/Views/VideoPage/video1_page.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:photo_manager/photo_manager.dart';
// import 'package:share/share.dart';
//
// class MediaViewerPage extends StatefulWidget {
//   final List<AssetEntity> media;
//   final int initialIndex;
//   final void Function(AssetEntity) onImageDeleted;
//   final bool isHiddenMedia;
//   final VoidCallback loadMedia;
//
//   const MediaViewerPage({
//     required this.media,
//     required this.initialIndex,
//     required this.onImageDeleted,
//     this.isHiddenMedia = false,
//     required this.loadMedia,
//   });
//
//   @override
//   _MediaViewerPageState createState() => _MediaViewerPageState();
// }
//
// class _MediaViewerPageState extends State<MediaViewerPage> {
//   late PageController _pageController;
//   int _currentIndex = 0;
//
//   @override
//   void initState() {
//     super.initState();
//     _currentIndex = widget.initialIndex;
//     _pageController = PageController(initialPage: _currentIndex);
//   }
//
//   Future<void> deleteImage() async {
//     if (_currentIndex >= widget.media.length) {
//       return;
//     }
//
//     final currentAsset = widget.media[_currentIndex];
//     try {
//       if (widget.isHiddenMedia) {
//         final directory = await getApplicationDocumentsDirectory();
//         final hiddenDirectory = Directory('${directory.path}/hidden_media');
//         final fileToDelete = File('${hiddenDirectory.path}/${currentAsset.id}');
//
//         // Check if the file exists before attempting deletion
//         if (await fileToDelete.exists()) {
//           await fileToDelete.delete();
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text('File not found: ${fileToDelete.path}')),
//           );
//         }
//       } else {
//         await PhotoManager.editor.deleteWithIds([currentAsset.id]);
//       }
//
//       widget.onImageDeleted(currentAsset);
//
//       setState(() {
//         widget.media.removeAt(_currentIndex);
//         widget.loadMedia();
//         if (widget.media.isEmpty) {
//           Navigator.of(context).pop();
//         } else {
//           if (_currentIndex >= widget.media.length) {
//             _currentIndex = widget.media.length - 1;
//           }
//           _pageController.jumpToPage(_currentIndex);
//         }
//       });
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to delete image: $e')),
//       );
//     }
//   }
//
//   // Future<void> deleteImage() async {
//   //   if (_currentIndex >= widget.media.length) {
//   //     return;
//   //   }
//   //
//   //   final currentAsset = widget.media[_currentIndex];
//   //   try {
//   //     if (widget.isHiddenMedia) {
//   //       final directory = await getApplicationDocumentsDirectory();
//   //       final hiddenDirectory = Directory('${directory.path}/hidden_media');
//   //       final fileToDelete = File('${hiddenDirectory.path}/${currentAsset.id}');
//   //
//   //       if (await fileToDelete.exists()) {
//   //         await fileToDelete.delete();
//   //       } else {
//   //         ScaffoldMessenger.of(context).showSnackBar(
//   //           SnackBar(content: Text('File not found: ${fileToDelete.path}')),
//   //         );
//   //       }
//   //     } else {
//   //       await PhotoManager.editor.deleteWithIds([currentAsset.id]);
//   //     }
//   //
//   //     widget.onImageDeleted(currentAsset);
//   //     setState(() {
//   //       widget.media.removeAt(_currentIndex);
//   //       widget.loadMedia();
//   //       if (widget.media.isEmpty) {
//   //         Navigator.of(context).pop();
//   //       } else {
//   //         if (_currentIndex >= widget.media.length) {
//   //           _currentIndex = widget.media.length - 1;
//   //         }
//   //         _pageController.jumpToPage(_currentIndex);
//   //       }
//   //     });
//   //   } catch (e) {
//   //     ScaffoldMessenger.of(context).showSnackBar(
//   //       SnackBar(content: Text('Failed to delete image: $e')),
//   //     );
//   //   }
//   // }
//
//   Future<void> shareImage(File file) async {
//     final directory = await getTemporaryDirectory();
//     final path = '${directory.path}/temp_image.jpg';
//     await file.copy(path);
//     await Share.shareFiles([path], text: 'Check out this image!');
//   }
//
//   Future<void> setAsWallpaper(File file) async {
//     try {
//       String? selectedLocation = await showModalBottomSheet<String>(
//         context: context,
//         builder: (context) {
//           if (Platform.isAndroid) {
//             return Container(
//               width: double.infinity,
//               padding: const EdgeInsets.all(16),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   TextButton(
//                     onPressed: () {
//                       Navigator.pop(context, 'home');
//                     },
//                     child: const Text(
//                       "Home Screen",
//                       style: TextStyle(
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                   TextButton(
//                     onPressed: () {
//                       Navigator.pop(context, 'lock');
//                     },
//                     child: const Text(
//                       "Lock Screen",
//                       style: TextStyle(
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                   TextButton(
//                     onPressed: () async {
//                       await AsyncWallpaper.setWallpaperFromFile(
//                         filePath: file.path,
//                         wallpaperLocation: AsyncWallpaper.LOCK_SCREEN,
//                       );
//
//                       Navigator.pop(context, 'both');
//                     },
//                     child: const Text(
//                       "Home and Lock Screens",
//                       style: TextStyle(
//                         color: Colors.black,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           } else {
//             return Container(
//               padding: const EdgeInsets.all(16),
//               child: const Center(
//                 child:
//                     Text('Setting wallpaper is not supported on this platform'),
//               ),
//             );
//           }
//         },
//       );
//
//       if (selectedLocation != null) {
//         bool result;
//         if (Platform.isAndroid) {
//           result = await AsyncWallpaper.setWallpaperFromFile(
//             filePath: file.path,
//             wallpaperLocation: selectedLocation == 'both'
//                 ? AsyncWallpaper.BOTH_SCREENS
//                 : (selectedLocation == 'home'
//                     ? AsyncWallpaper.HOME_SCREEN
//                     : AsyncWallpaper.LOCK_SCREEN),
//             goToHome: false,
//           );
//
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Text(
//                 result
//                     ? 'Wallpaper set successfully'
//                     : 'Failed to set wallpaper',
//               ),
//             ),
//           );
//         } else if (Platform.isIOS) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//               content: Text('Setting wallpaper is not supported on iOS'),
//             ),
//           );
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//               content: Text('Unsupported platform'),
//             ),
//           );
//         }
//       }
//     } catch (e) {
//       print('Error $e');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to set wallpaper: $e')),
//       );
//     }
//   }
//
//   Future<void> shareVideo(File file) async {
//     final directory = await getTemporaryDirectory();
//     final path = '${directory.path}/temp_video.mp4';
//     await file.copy(path);
//     await Share.shareFiles([path], text: 'Check out this video!');
//   }
//
//   Future<void> hideMedia(AssetEntity asset) async {
//     try {
//       // Retrieve the file associated with the asset
//       final file = await asset.file;
//       if (file == null) return;
//
//       // Get the application documents directory
//       final directory = await getApplicationDocumentsDirectory();
//
//       // Define the hidden media directory path
//       final hiddenDirectory = Directory('${directory.path}/hidden_media');
//
//       // Check if the hidden directory exists, if not, create it
//       if (!await hiddenDirectory.exists()) {
//         await hiddenDirectory.create(
//             recursive: true); // Create the directory recursively
//       }
//
//       // Construct the new path for the file to be hidden
//       final newPath = '${hiddenDirectory.path}/${file.uri.pathSegments.last}';
//
//       // Copy the file to the hidden directory
//       await file.copy(newPath);
//
//       // Optionally, delete the original file if needed
//       // await file.delete();
//
//       // Update the UI to reflect the changes
//       setState(() {
//         widget.media.remove(asset);
//         widget.loadMedia();
//       });
//
//       // Notify the user that the media was hidden successfully
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Media hidden successfully')),
//       );
//     } catch (e) {
//       print('Error: $e');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to hide media: $e')),
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final AssetEntity currentAsset = widget.media[_currentIndex];
//
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () {
//             Navigator.pop(context);
//           },
//           icon: const Icon(Icons.arrow_back_ios),
//         ),
//         title: Text(currentAsset.type == AssetType.video ? 'Video' : 'Image'),
//         actions: [
//           PopupMenuButton<String>(
//             onSelected: (value) async {
//               final file =
//                   await currentAsset.file; // Obtain the file from AssetEntity
//
//               if (file == null) {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('File not available.')),
//                 );
//                 return; // Return early if the file is null
//               }
//               switch (value) {
//                 case 'share':
//                   if (currentAsset.type == AssetType.video) {
//                     await shareVideo(file);
//                   } else {
//                     await shareImage(file);
//                   }
//                   break;
//                 case 'delete':
//                   await deleteImage();
//                   break;
//                 case 'hide':
//                   await hideMedia(currentAsset);
//                   break;
//                 case 'set_as_wallpaper':
//                   if (currentAsset.type == AssetType.image) {
//                     await setAsWallpaper(file);
//                   }
//                   break;
//               }
//             },
//             itemBuilder: (context) => currentAsset.type == AssetType.video
//                 ? [
//                     const PopupMenuItem(value: 'share', child: Text('Share')),
//                     const PopupMenuItem(value: 'delete', child: Text('Delete')),
//                     const PopupMenuItem(value: 'hide', child: Text('Hide')),
//                   ]
//                 : [
//                     const PopupMenuItem(value: 'share', child: Text('Share')),
//                     const PopupMenuItem(value: 'delete', child: Text('Delete')),
//                     const PopupMenuItem(
//                         value: 'set_as_wallpaper',
//                         child: Text('Set as Wallpaper')),
//                     const PopupMenuItem(value: 'hide', child: Text('Hide')),
//                   ],
//           ),
//         ],
//       ),
//       body: PageView.builder(
//         controller: _pageController,
//         itemCount: widget.media.length,
//         onPageChanged: (index) {
//           setState(() {
//             _currentIndex = index;
//           });
//         },
//         itemBuilder: (context, index) {
//           if (index >= widget.media.length) {
//             return const SizedBox.shrink();
//           }
//           final asset = widget.media[index];
//           return FutureBuilder<File?>(
//             future: asset.file,
//             builder: (context, snapshot) {
//               if (snapshot.connectionState == ConnectionState.waiting) {
//                 return const Center(child: CircularProgressIndicator());
//               } else if (snapshot.hasError || !snapshot.hasData) {
//                 return const Center(child: Text('Error loading media'));
//               } else {
//                 final file = snapshot.data!;
//                 if (asset.type == AssetType.video) {
//                   return VideoPage(file: file, index: index);
//                 } else {
//                   return ImagePage(
//                       imageFile: file,
//                       onDelete: () async {
//                         await deleteImage();
//                       });
//                 }
//               }
//             },
//           );
//         },
//       ),
//     );
//   }
// }

// class _MediaViewerPageState extends State<MediaViewerPage> {
//   late PageController _pageController;
//   int _currentIndex = 0;
//
//   @override
//   void initState() {
//     super.initState();
//     _currentIndex = widget.initialIndex;
//     _pageController = PageController(initialPage: _currentIndex);
//   }
//
//   Future<void> deleteImage() async {
//     if (_currentIndex >= widget.media.length) return;
//
//     final currentAsset = widget.media[_currentIndex];
//     try {
//       if (widget.isHiddenMedia) {
//         final directory = await getApplicationDocumentsDirectory();
//         final hiddenDirectory = Directory('${directory.path}/hidden_media');
//         final fileToDelete = File('${hiddenDirectory.path}/${currentAsset.id}');
//
//         if (await fileToDelete.exists()) {
//           await fileToDelete.delete();
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text('File not found: ${fileToDelete.path}')),
//           );
//         }
//       } else {
//         await PhotoManager.editor.deleteWithIds([currentAsset.id]);
//       }
//
//       widget.onImageDeleted(currentAsset);
//       setState(() {
//         widget.media.removeAt(_currentIndex);
//         widget.loadMedia();
//         if (widget.media.isEmpty) {
//           Navigator.of(context).pop();
//         } else {
//           if (_currentIndex >= widget.media.length) {
//             _currentIndex = widget.media.length - 1;
//           }
//           _pageController.jumpToPage(_currentIndex);
//         }
//       });
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to delete image: $e')),
//       );
//     }
//   }
//
//   Future<void> shareImage(File file) async {
//     final directory = await getTemporaryDirectory();
//     final path = '${directory.path}/temp_image.jpg';
//     await file.copy(path);
//     await Share.shareFiles([path], text: 'Check out this image!');
//   }
//
//   Future<void> setAsWallpaper(File file) async {
//     try {
//       final selectedLocation = await showModalBottomSheet<String>(
//         context: context,
//         builder: (context) {
//           if (Platform.isAndroid) {
//             return Container(
//               width: double.infinity,
//               padding: const EdgeInsets.all(16),
//               child: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   TextButton(
//                     onPressed: () {
//                       Navigator.pop(context, 'home');
//                     },
//                     child: const Text("Home Screen",
//                         style: TextStyle(color: Colors.black)),
//                   ),
//                   TextButton(
//                     onPressed: () {
//                       Navigator.pop(context, 'lock');
//                     },
//                     child: const Text("Lock Screen",
//                         style: TextStyle(color: Colors.black)),
//                   ),
//                   TextButton(
//                     onPressed: () async {
//                       // await AsyncWallpaper.setWallpaperFromFile(
//                       //   filePath: file.path,
//                       //   wallpaperLocation: AsyncWallpaper.LOCK_SCREEN,
//                       // );
//
//                       Navigator.pop(context, 'both');
//                     },
//                     child: const Text("Home and Lock Screens",
//                         style: TextStyle(color: Colors.black)),
//                   ),
//                 ],
//               ),
//             );
//           } else {
//             return Container(
//               padding: const EdgeInsets.all(16),
//               child: const Center(
//                 child:
//                     Text('Setting wallpaper is not supported on this platform'),
//               ),
//             );
//           }
//         },
//       );
//
//       if (selectedLocation != null) {
//         bool result = false;
//         if (Platform.isAndroid) {
//           result = await AsyncWallpaper.setWallpaperFromFile(
//             filePath: file.path,
//             wallpaperLocation: selectedLocation == 'both'
//                 ? AsyncWallpaper.BOTH_SCREENS
//                 : (selectedLocation == 'home'
//                     ? AsyncWallpaper.HOME_SCREEN
//                     : AsyncWallpaper.LOCK_SCREEN),
//             goToHome: false,
//           );
//
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Text(result
//                   ? 'Wallpaper set successfully'
//                   : 'Failed to set wallpaper'),
//             ),
//           );
//         } else if (Platform.isIOS) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//                 content: Text('Setting wallpaper is not supported on iOS')),
//           );
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(content: Text('Unsupported platform')),
//           );
//         }
//       }
//     } catch (e) {
//       print('Error $e');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to set wallpaper: $e')),
//       );
//     }
//   }
//
//   Future<void> shareVideo(File file) async {
//     final directory = await getTemporaryDirectory();
//     final path = '${directory.path}/temp_video.mp4';
//     await file.copy(path);
//     await Share.shareFiles([path], text: 'Check out this video!');
//   }
//
//   Future<void> hideMedia(AssetEntity asset) async {
//     try {
//       final file = await asset.file;
//       if (file == null) return;
//
//       final directory = await getApplicationDocumentsDirectory();
//       final hiddenDirectory = Directory('${directory.path}/hidden_media');
//
//       if (!await hiddenDirectory.exists()) {
//         await hiddenDirectory.create(recursive: true);
//       }
//
//       final newPath = '${hiddenDirectory.path}/${file.uri.pathSegments.last}';
//
//       // Copy the file to the hidden directory
//       if (!await File(newPath).exists()) {
//         await file.copy(newPath);
//       }
//
//       // Remove the asset from the media list
//       setState(() {
//         widget.media.remove(asset);
//       });
//
//       // Notify the parent or any listeners that an image was deleted
//       widget.onImageDeleted(asset);
//
//       // Update the media in all pages
//       widget.loadMedia();
//
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Media hidden successfully')),
//       );
//     } catch (e) {
//       print('Error: $e');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Failed to hide media: $e')),
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final AssetEntity currentAsset = widget.media[_currentIndex];
//
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () {
//             Navigator.pop(context);
//           },
//           icon: const Icon(Icons.arrow_back_ios),
//         ),
//         title: Text(currentAsset.type == AssetType.video ? 'Video' : 'Image'),
//         actions: [
//           PopupMenuButton<String>(
//             onSelected: (value) async {
//               final file = await currentAsset.file;
//
//               if (file == null) {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('File not available.')),
//                 );
//                 return;
//               }
//               switch (value) {
//                 case 'share':
//                   if (currentAsset.type == AssetType.video) {
//                     await shareVideo(file);
//                   } else {
//                     await shareImage(file);
//                   }
//                   break;
//                 case 'delete':
//                   final shouldDelete = await showDialog<bool>(
//                     context: context,
//                     builder: (context) => AlertDialog(
//                       title: const Text('Delete Media'),
//                       content: const Text(
//                           'Are you sure you want to delete this media?'),
//                       actions: [
//                         TextButton(
//                           onPressed: () => Navigator.pop(context, false),
//                           child: const Text('Cancel'),
//                         ),
//                         TextButton(
//                           onPressed: () => Navigator.pop(context, true),
//                           child: const Text('Delete'),
//                         ),
//                       ],
//                     ),
//                   );
//                   if (shouldDelete == true) {
//                     await deleteImage();
//                   }
//                   break;
//                 case 'hide':
//                   final shouldHide = await showDialog<bool>(
//                     context: context,
//                     builder: (context) => AlertDialog(
//                       title: const Text('Hide Media'),
//                       content: const Text(
//                           'Are you sure you want to hide this media?'),
//                       actions: [
//                         TextButton(
//                           onPressed: () => Navigator.pop(context, false),
//                           child: const Text('Cancel'),
//                         ),
//                         TextButton(
//                           onPressed: () => Navigator.pop(context, true),
//                           child: const Text('Hide'),
//                         ),
//                       ],
//                     ),
//                   );
//                   if (shouldHide == true) {
//                     await hideMedia(currentAsset);
//                   }
//                   break;
//                 case 'set_as_wallpaper':
//                   if (currentAsset.type == AssetType.image) {
//                     await setAsWallpaper(file);
//                   }
//                   break;
//               }
//             },
//             itemBuilder: (context) => currentAsset.type == AssetType.video
//                 ? [
//                     const PopupMenuItem(value: 'share', child: Text('Share')),
//                     const PopupMenuItem(value: 'delete', child: Text('Delete')),
//                     const PopupMenuItem(value: 'hide', child: Text('Hide')),
//                   ]
//                 : [
//                     const PopupMenuItem(value: 'share', child: Text('Share')),
//                     const PopupMenuItem(value: 'delete', child: Text('Delete')),
//                     const PopupMenuItem(
//                         value: 'set_as_wallpaper',
//                         child: Text('Set as Wallpaper')),
//                     const PopupMenuItem(value: 'hide', child: Text('Hide')),
//                   ],
//           ),
//         ],
//       ),
//       body: PageView.builder(
//         controller: _pageController,
//         itemCount: widget.media.length,
//         onPageChanged: (index) {
//           setState(() {
//             _currentIndex = index;
//           });
//         },
//         itemBuilder: (context, index) {
//           if (index >= widget.media.length) return const SizedBox.shrink();
//
//           final asset = widget.media[index];
//           return FutureBuilder<File?>(
//             future: asset.file,
//             builder: (context, snapshot) {
//               if (snapshot.connectionState == ConnectionState.waiting) {
//                 return const Center(child: CircularProgressIndicator());
//               } else if (snapshot.hasError || !snapshot.hasData) {
//                 return const Center(child: Text('Error loading media'));
//               } else {
//                 final file = snapshot.data!;
//                 if (asset.type == AssetType.video) {
//                   return VideoPage(file: file, index: index);
//                 } else {
//                   return ImagePage(
//                       imageFile: file,
//                       onDelete: () async {
//                         await deleteImage();
//                       },
//                       // onHide: () async {
//                       //   await hideMedia(asset);
//                       // },
//                   );
//                 }
//               }
//             },
//           );
//         },
//       ),
//     );
//   }
// }
import 'dart:io';

import 'package:async_wallpaper/async_wallpaper.dart';
import 'package:flutter/material.dart';
import 'package:gallery_app/Views/HideMedia/hide_media.dart';
import 'package:gallery_app/Views/ImagePage/image1_page.dart';
import 'package:gallery_app/Views/VideoPage/video1_page.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:share/share.dart';

import 'dart:io';

import 'package:async_wallpaper/async_wallpaper.dart';
import 'package:flutter/material.dart';
import 'package:gallery_app/Views/HideMedia/hide_media.dart';
import 'package:gallery_app/Views/ImagePage/image1_page.dart';
import 'package:gallery_app/Views/VideoPage/video1_page.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:share/share.dart';

class MediaViewerPage extends StatefulWidget {
  final List<MediaFile> media;
  final int initialIndex;
  final void Function(MediaFile) onImageDeleted;
  final bool isHiddenMedia;
  final VoidCallback loadMedia;

  const MediaViewerPage({
    required this.media,
    required this.initialIndex,
    required this.onImageDeleted,
    this.isHiddenMedia = false,
    required this.loadMedia,
  });

  @override
  _MediaViewerPageState createState() => _MediaViewerPageState();
}

class _MediaViewerPageState extends State<MediaViewerPage> {
  late PageController _pageController;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: _currentIndex);
  }

  Future<void> deleteImage() async {
    if (_currentIndex >= widget.media.length) {
      return;
    }

    final currentAsset = widget.media[_currentIndex];

    if (widget.isHiddenMedia) {
      final directory = await getApplicationDocumentsDirectory();
      final hiddenDirectory = Directory('${directory.path}/hidden_media');
      final fileToDelete = File('${hiddenDirectory.path}/${currentAsset.id}');
      if (await fileToDelete.exists()) {
        await fileToDelete.delete();
      }
    } else {
      await PhotoManager.editor.deleteWithIds([currentAsset.id]);
    }

    widget.onImageDeleted(currentAsset);

    setState(() {
      widget.media.removeAt(_currentIndex);
      widget.loadMedia;
      if (widget.media.isEmpty) {
        Navigator.of(context).pop();
      } else {
        if (_currentIndex >= widget.media.length) {
          _currentIndex = widget.media.length - 1;
        }
        _pageController.jumpToPage(_currentIndex);
      }
    });
  }

  Future<void> shareImage(File file) async {
    final directory = await getTemporaryDirectory();
    final path = '${directory.path}/temp_image.jpg';
    await file.copy(path);
    await Share.shareFiles([path], text: 'Check out this image!');
  }

  Future<void> setAsWallpaper(File file) async {
    try {
      String? selectedLocation = await showModalBottomSheet<String>(
        context: context,
        builder: (context) {
          if (Platform.isAndroid) {
            return Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context, 'home');
                    },
                    child: const Text(
                      "Home Screen",
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context, 'lock');
                    },
                    child: const Text(
                      "Lock Screen",
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      await AsyncWallpaper.setWallpaperFromFile(
                        filePath: file.path,
                        wallpaperLocation: AsyncWallpaper.LOCK_SCREEN,
                      );

                      Navigator.pop(context, 'both');
                    },
                    child: const Text(
                      "Home and Lock Screens",
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            );
          } else {
            return Container(
              padding: const EdgeInsets.all(16),
              child: const Center(
                child:
                    Text('Setting wallpaper is not supported on this platform'),
              ),
            );
          }
        },
      );

      if (selectedLocation != null) {
        bool result;
        if (Platform.isAndroid) {
          result = await AsyncWallpaper.setWallpaperFromFile(
            filePath: file.path,
            wallpaperLocation: selectedLocation == 'both'
                ? AsyncWallpaper.BOTH_SCREENS
                : (selectedLocation == 'home'
                    ? AsyncWallpaper.HOME_SCREEN
                    : AsyncWallpaper.LOCK_SCREEN),
            goToHome: false,
          );

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                result
                    ? 'Wallpaper set successfully'
                    : 'Failed to set wallpaper',
              ),
            ),
          );
        } else if (Platform.isIOS) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Setting wallpaper is not supported on iOS'),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Unsupported platform'),
            ),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to set wallpaper: $e')),
      );
    }
  }

  Future<void> shareVideo(File file) async {
    final directory = await getTemporaryDirectory();
    final path = '${directory.path}/temp_video.mp4';
    await file.copy(path);
    await Share.shareFiles([path], text: 'Check out this video!');
  }

  // Future<void> hideMedia(File file) async {
  //   final directory = await getApplicationDocumentsDirectory();
  //   final hiddenDirectory = Directory('${directory.path}/hidden_media');
  //   if (!await hiddenDirectory.exists()) {
  //     await hiddenDirectory.create();
  //   }
  //
  //   final newPath = '${hiddenDirectory.path}/${file.uri.pathSegments.last}';
  //   await file.copy(newPath);
  //
  //   await deleteImage();
  // }

  Future<void> hideMedia(AssetEntity asset) async {
    try {
      final file = await asset.file;
      if (file == null) return;

      final directory = await getApplicationDocumentsDirectory();
      final hiddenDirectory = Directory('${directory.path}/hidden_media');

      if (!await hiddenDirectory.exists()) {
        await hiddenDirectory.create(recursive: true);
      }

      final newPath = '${hiddenDirectory.path}/${file.uri.pathSegments.last}';

      // Copy the file to the hidden directory
      if (!await File(newPath).exists()) {
        await file.copy(newPath);
      }

      // Remove the asset from the media list
      setState(() {
        widget.media.remove(asset);
      });

      // Notify the parent or any listeners that an image was deleted
      widget.onImageDeleted(asset as MediaFile);

      // Update the media in all pages
      widget.loadMedia();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Media hidden successfully')),
      );
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to hide media: $e')),
      );
    }
  }
  // Future<void> hideMedia(AssetEntity asset) async {
  //   try {
  //     // Retrieve the file associated with the asset
  //     final file = await asset.file;
  //     if (file == null) return;
  //
  //     // Get the application documents directory
  //     final directory = await getApplicationDocumentsDirectory();
  //
  //     // Define the hidden media directory path
  //     final hiddenDirectory = Directory('${directory.path}/hidden_media');
  //
  //     // Check if the hidden directory exists, if not, create it
  //     if (!await hiddenDirectory.exists()) {
  //       await hiddenDirectory.create(
  //           recursive: true); // Create the directory recursively
  //     }
  //
  //     // Construct the new path for the file to be hidden
  //     final newPath = '${hiddenDirectory.path}/${file.uri.pathSegments.last}';
  //
  //     // Copy the file to the hidden directory
  //     await file.copy(newPath);
  //
  //     // Optionally, delete the original file if needed
  //     // await file.delete();
  //
  //     // Update the UI to reflect the changes
  //     setState(() {
  //       widget.media.remove(asset);
  //       widget.loadMedia();
  //     });
  //
  //     // Notify the user that the media was hidden successfully
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(content: Text('Media hidden successfully')),
  //     );
  //   } catch (e) {
  //     print('Error: $e');
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('Failed to hide media: $e')),
  //     );
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    final MediaFile currentAsset = widget.media[_currentIndex];

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () async {
            // await widget.loadMedia();
            setState(() {});
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios),
        ),
        title: Text(currentAsset.isVideo ? 'Video' : 'Image'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (currentAsset.isVideo) {
                switch (value) {
                  case 'share':
                    await shareVideo(currentAsset as File);
                    break;
                  case 'delete':
                    await deleteImage();
                    break;
                  case 'hide':
                    await hideMedia(currentAsset as AssetEntity);
                    break;
                }
              } else {
                switch (value) {
                  case 'share':
                    await shareImage(currentAsset as File);
                    break;
                  case 'delete':
                    await deleteImage();
                    break;
                  case 'set_as_wallpaper':
                    await setAsWallpaper(currentAsset as File);
                    break;
                  case 'hide':
                    await hideMedia(currentAsset as AssetEntity);
                    break;
                }
              }
            },
            itemBuilder: (context) => currentAsset.isVideo
                ? [
                    const PopupMenuItem(value: 'share', child: Text('Share')),
                    const PopupMenuItem(value: 'delete', child: Text('Delete')),
                    const PopupMenuItem(value: 'hide', child: Text('Hide')),
                  ]
                : [
                    const PopupMenuItem(value: 'share', child: Text('Share')),
                    const PopupMenuItem(value: 'delete', child: Text('Delete')),
                    const PopupMenuItem(
                        value: 'set_as_wallpaper',
                        child: Text('Set as Wallpaper')),
                    const PopupMenuItem(value: 'hide', child: Text('Hide')),
                  ],
          ),
        ],
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.media.length,
        onPageChanged: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        itemBuilder: (context, index) {
          if (index >= widget.media.length) {
            return const SizedBox.shrink();
          }
          final asset = widget.media[index];
          // Use a FutureBuilder to handle asynchronous data fetching
          return FutureBuilder<File?>(
            future: _getFile(asset.path),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError || !snapshot.hasData) {
                return const Center(child: Text('Error loading media'));
              } else {
                final file = snapshot.data!;
                if (asset.isVideo) {
                  return VideoPage(
                    file: file,
                    index: index,
                  );
                } else {
                  return ImagePage(
                    imageFile: file,
                    onDelete: () async {
                      await deleteImage();
                    },
                  );
                }
              }
            },
          );
        },
      ),
    );
  }
}

// Method to check if a file exists and return it
Future<File?> _getFile(String path) async {
  final file = File(path);
  return await file.exists() ? file : null;
}
