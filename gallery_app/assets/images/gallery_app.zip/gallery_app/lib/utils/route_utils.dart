import 'package:flutter/material.dart';
import 'package:gallery_app/Views/AlbumsPage/albums_page.dart';
import 'package:gallery_app/Views/home_page/home_page.dart';
import 'package:gallery_app/Views/inro_page/get_started.dart';
import 'package:gallery_app/Views/inro_page/intro_page.dart';
import 'package:gallery_app/Views/splash_screen/splash_screen.dart';

class AppRoutes {
  static String splashScreen = '/';
  static String introScreen = '/intro_screen';
  static String getStartPage = '/get_start_page';
  static String homePage = '/home_page';
  static String albumsPage = '/albums_page';
  static String albumPage = '/album_page';
  static String imagePage = '/image_page';
  static String videoPage = '/video_page';
  static String mediaViewerPage = '/media_viewer_page';
  static String hiddenPage = '/hidden_page';

  static Map<String, WidgetBuilder> routes = {
    AppRoutes.splashScreen: (context) => SplashScreen(),
    AppRoutes.getStartPage: (context) => GetStartScreen(),
    AppRoutes.introScreen: (context) => IntroScreen(),
    AppRoutes.homePage: (context) => HomePage(),
    AppRoutes.albumsPage: (context) => AlbumsPage(
          onToggleButtonVisibilityChanged: (bool) {},
        ),
    // AppRoutes.albumsPage:(context)=> AlbumPage(album: album),
  };

  AppRoutes._();
  static final AppRoutes appRoutes = AppRoutes._();
}
