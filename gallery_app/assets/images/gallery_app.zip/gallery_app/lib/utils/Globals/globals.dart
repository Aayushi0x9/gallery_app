class Globals {
  Globals._();
  Globals globals = Globals._();
  static bool hide = false;
  static bool isGridView = true;
}
