// // import 'dart:io';
// // import 'dart:typed_data';
// // import 'package:draggable_scrollbar/draggable_scrollbar.dart';
// // import 'package:flutter/material.dart';
// // import 'package:path_provider/path_provider.dart';
// // import 'package:photo_manager/photo_manager.dart';
// // import 'package:gallery_app/Views/HideMedia/hide_media.dart';
// // import 'package:gallery_app/Widget/MediaViewerpage/media_tile.dart';
// //
// // class AlbumPage extends StatefulWidget {
// //   final AssetPathEntity album;
// //   final int initialIndex;
// //   final VoidCallback? onDelete;
// //
// //   AlbumPage({required this.album, this.initialIndex = 0, this.onDelete});
// //
// //   @override
// //   _AlbumPageState createState() => _AlbumPageState();
// // }
// //
// // class _AlbumPageState extends State<AlbumPage> {
// //   final List<AssetEntity> _media = [];
// //   bool _isLoading = true;
// //   final ScrollController _scrollController = ScrollController();
// //   int _loadedAssets = 0;
// //   final int _batchSize = 50;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     _loadMedia();
// //     _scrollController.addListener(_onScroll);
// //   }
// //   //
// //   // Future<void> _loadMedia() async {
// //   //   try {
// //   //     final int assetCount = await widget.album.assetCountAsync;
// //   //     final end = (_loadedAssets + _batchSize > assetCount)
// //   //         ? assetCount
// //   //         : _loadedAssets + _batchSize;
// //   //
// //   //     if (_loadedAssets < assetCount) {
// //   //       final media = await widget.album.getAssetListRange(
// //   //         start: _loadedAssets,
// //   //         end: end,
// //   //       );
// //   //
// //   //       final hiddenFiles = await _getHiddenMediaPaths();
// //   //
// //   //       final visibleMedia = await Future.wait(
// //   //         media.map((asset) async {
// //   //           final file = await asset.file;
// //   //           return file != null && !hiddenFiles.contains(file.path)
// //   //               ? asset
// //   //               : null;
// //   //         }),
// //   //       );
// //   //
// //   //       final nonNullMedia = visibleMedia.whereType<AssetEntity>().toList();
// //   //
// //   //       setState(() {
// //   //         _media.addAll(nonNullMedia);
// //   //         _loadedAssets = end;
// //   //         _isLoading = false;
// //   //       });
// //   //     }
// //   //   } catch (e) {
// //   //     print('Error loading media: $e');
// //   //     setState(() {
// //   //       _isLoading = false;
// //   //     });
// //   //   }
// //   // }
// //
// //   Future<List<String>> _getHiddenMediaPaths() async {
// //     final directory = await getApplicationDocumentsDirectory();
// //     final hiddenDirectory = Directory('${directory.path}/hidden_media');
// //     if (hiddenDirectory.existsSync()) {
// //       return hiddenDirectory.listSync().map((f) => f.path).toList();
// //     }
// //     return [];
// //   }
// //
// //   void _onScroll() {
// //     if (_scrollController.position.pixels >=
// //             _scrollController.position.maxScrollExtent - 200 &&
// //         !_isLoading) {
// //       _loadMoreMedia();
// //     }
// //   }
// //
// //   Future<void> _loadMoreMedia() async {
// //     setState(() {
// //       _isLoading = true;
// //     });
// //     await _loadMedia();
// //     setState(() {
// //       _isLoading = false;
// //     });
// //   }
// //
// //   void _removeImage(AssetEntity asset) async {
// //     try {
// //       setState(() {
// //         _media.remove(asset);
// //       });
// //
// //       if (_media.isEmpty) {
// //         widget.onDelete?.call();
// //         WidgetsBinding.instance.addPostFrameCallback((_) {
// //           Navigator.of(context).pop();
// //         });
// //       }
// //     } catch (e) {
// //       print('Error deleting image: $e');
// //     }
// //   }
// //
// //   Future<void> _refreshMedia() async {
// //     setState(() {
// //       _isLoading = true;
// //     });
// //     await _loadMedia();
// //     setState(() {
// //       _isLoading = false;
// //     });
// //   }
// //
// //   @override
// //   void dispose() {
// //     _scrollController.removeListener(_onScroll);
// //     _scrollController.dispose();
// //     super.dispose();
// //   }
// //
// //   Map<AssetEntity, MediaFile> _assetToMediaFileMap = {};
// //
// //   Future<void> _loadMedia() async {
// //     try {
// //       final int assetCount = await widget.album.assetCountAsync;
// //       final end = (_loadedAssets + _batchSize > assetCount)
// //           ? assetCount
// //           : _loadedAssets + _batchSize;
// //
// //       if (_loadedAssets < assetCount) {
// //         final media = await widget.album.getAssetListRange(
// //           start: _loadedAssets,
// //           end: end,
// //         );
// //
// //         // Get list of hidden file paths
// //         final directory = await getApplicationDocumentsDirectory();
// //         final hiddenDirectory = Directory('${directory.path}/hidden_media');
// //         final hiddenFiles = hiddenDirectory.existsSync()
// //             ? hiddenDirectory.listSync().map((f) => f.path).toList()
// //             : [];
// //
// //         final visibleMedia = await Future.wait(
// //           media.map((asset) async {
// //             final file = await asset.file;
// //             return file != null && !hiddenFiles.contains(file.path)
// //                 ? asset
// //                 : null;
// //           }),
// //         );
// //
// //         // Create MediaFile objects and map them
// //         final nonNullMedia = visibleMedia.whereType<AssetEntity>().toList();
// //         final mediaFiles =
// //             await Future.wait(_convertAssetsToMediaFiles(nonNullMedia));
// //         _assetToMediaFileMap = Map.fromIterables(nonNullMedia, mediaFiles);
// //
// //         setState(() {
// //           _media.addAll(nonNullMedia);
// //           _loadedAssets = end;
// //           _isLoading = false;
// //         });
// //       }
// //     } catch (e) {
// //       print('Error loading media: $e');
// //       setState(() {
// //         _isLoading = false;
// //       });
// //     }
// //   }
// //
// //   List<Future<MediaFile>> _convertAssetsToMediaFiles(List<AssetEntity> assets) {
// //     return assets.map((asset) async {
// //       final file = await asset.file;
// //       final filePath = file?.path ?? '';
// //       return MediaFile(
// //         id: asset.id,
// //         path: filePath,
// //         isVideo: asset.type == AssetType.video,
// //       );
// //     }).toList();
// //   }
// //
// //   //
// //   // List<Future<MediaFile>> _convertAssetsToMediaFiles(List<AssetEntity> assets) {
// //   //   return assets.map((asset) async {
// //   //     final file = await asset.file;
// //   //     final filePath = file?.path ?? '';
// //   //     return MediaFile(
// //   //       id: asset.id,
// //   //       path: filePath,
// //   //       isVideo: asset.type == AssetType.video,
// //   //     );
// //   //   }).toList();
// //   // }
// //   //
// //   @override
// //   Widget build(BuildContext context) {
// //     return LayoutBuilder(
// //       builder: (context, constraints) {
// //         final Size size = Size(constraints.maxWidth, constraints.maxHeight);
// //         return Scaffold(
// //           appBar: AppBar(
// //             title: Text(widget.album.name),
// //             leading: IconButton(
// //               onPressed: () {
// //                 Navigator.pop(context);
// //               },
// //               icon: const Icon(Icons.arrow_back_ios),
// //             ),
// //           ),
// //           body: _isLoading && _media.isEmpty
// //               ? const Center(child: CircularProgressIndicator())
// //               : _media.isEmpty
// //                   ? const Center(child: Text('No media available'))
// //                   : LayoutBuilder(
// //                       builder: (context, constraints) =>
// //                           DraggableScrollbar.semicircle(
// //                         controller: _scrollController,
// //                         child: GridView.builder(
// //                           controller: _scrollController,
// //                           gridDelegate:
// //                               const SliverGridDelegateWithFixedCrossAxisCount(
// //                             crossAxisCount: 3,
// //                             crossAxisSpacing: 4.0,
// //                             mainAxisSpacing: 4.0,
// //                           ),
// //                           itemCount: _media.length + (_isLoading ? 1 : 0),
// //                           itemBuilder: (context, index) {
// //                             if (index == _media.length) {
// //                               return const Center(
// //                                   child: CircularProgressIndicator());
// //                             }
// //                             final asset = _media[index];
// //                             return FutureBuilder<Uint8List?>(
// //                               future: asset.thumbnailDataWithSize(
// //                                   const ThumbnailSize.square(200)),
// //                               builder: (context, snapshot) {
// //                                 if (snapshot.connectionState ==
// //                                     ConnectionState.waiting) {
// //                                   return const Center(
// //                                       child: CircularProgressIndicator());
// //                                 } else if (snapshot.hasError ||
// //                                     !snapshot.hasData) {
// //                                   return const Center(
// //                                       child: Text('Error loading thumbnail'));
// //                                 } else {
// //                                   final Uint8List? thumbnail = snapshot.data;
// //                                   return GestureDetector(
// //                                     onTap: () =>
// //                                         _openMediaViewer(context, index),
// //                                     child: Container(
// //                                       padding: const EdgeInsets.all(5),
// //                                       decoration: BoxDecoration(
// //                                         borderRadius: BorderRadius.circular(8),
// //                                         image: thumbnail != null
// //                                             ? DecorationImage(
// //                                                 image: MemoryImage(thumbnail),
// //                                                 fit: BoxFit.cover,
// //                                               )
// //                                             : null,
// //                                       ),
// //                                     ),
// //                                   );
// //                                 }
// //                               },
// //                             );
// //                           },
// //                         ),
// //                       ),
// //                     ),
// //         );
// //       },
// //     );
// //   }
// //
// //   Future<void> _openMediaViewer(BuildContext context, int index) async {
// //     final mediaFiles = await Future.wait(_convertAssetsToMediaFiles(_media));
// //
// //     if (mediaFiles.isNotEmpty) {
// //       final result = await Navigator.of(context).push(
// //         MaterialPageRoute(
// //           builder: (context) => MediaViewerPage(
// //             initialIndex: index,
// //             media: _media,
// //             onImageDeleted: (mediaFile) {
// //               _removeImage(_media[index]);
// //             },
// //             loadMedia: _refreshMedia,
// //           ),
// //         ),
// //       );
// //
// //       if (result != null) {
// //         _refreshMedia(); // Refresh media after deletion
// //       }
// //     } else {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         const SnackBar(content: Text('No media available')),
// //       );
// //     }
// //   }
// // }
// import 'dart:io';
// import 'dart:typed_data';
// import 'package:draggable_scrollbar/draggable_scrollbar.dart';
// import 'package:flutter/material.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:photo_manager/photo_manager.dart';
// import 'package:gallery_app/Views/HideMedia/hide_media.dart';
// import 'package:gallery_app/Widget/MediaViewerpage/media_tile.dart';
//
// class AlbumPage extends StatefulWidget {
//   final AssetPathEntity album;
//   final int initialIndex;
//   final VoidCallback? onDelete;
//
//   AlbumPage({required this.album, this.initialIndex = 0, this.onDelete});
//
//   @override
//   _AlbumPageState createState() => _AlbumPageState();
// }
//
// class _AlbumPageState extends State<AlbumPage> {
//   final List<AssetEntity> _media = [];
//   bool _isLoading = true;
//   final ScrollController _scrollController = ScrollController();
//   int _loadedAssets = 0;
//   final int _batchSize = 50;
//
//   @override
//   void initState() {
//     super.initState();
//     _loadMedia();
//     _scrollController.addListener(_onScroll);
//   }
//
//   // Future<List<String>> _getHiddenMediaPaths() async {
//   //   final directory = await getApplicationDocumentsDirectory();
//   //   final hiddenDirectory = Directory('${directory.path}/hidden_media');
//   //   if (hiddenDirectory.existsSync()) {
//   //     return hiddenDirectory.listSync().map((f) => f.path).toList();
//   //   }
//   //   return [];
//   // }
// // Example method to get hidden media file paths
//   Future<List<String>> _getHiddenMediaPaths() async {
//     try {
//       final directory = await getApplicationDocumentsDirectory();
//       final hiddenDirectory = Directory('${directory.path}/hidden_media');
//       if (!await hiddenDirectory.exists()) {
//         return [];
//       }
//
//       final hiddenFiles = await hiddenDirectory.list().toList();
//       return hiddenFiles.map((file) => file.path).toList();
//     } catch (e) {
//       print('Error retrieving hidden media paths: $e');
//       return [];
//     }
//   }
//
//   void _onScroll() {
//     if (_scrollController.position.pixels >=
//             _scrollController.position.maxScrollExtent - 200 &&
//         !_isLoading) {
//       _loadMoreMedia();
//     }
//   }
//
//   Future<void> _loadMoreMedia() async {
//     setState(() {
//       _isLoading = true;
//     });
//     await _loadMedia();
//     setState(() {
//       _isLoading = false;
//     });
//   }
//
//   void _removeImage(AssetEntity asset) async {
//     try {
//       setState(() {
//         _media.remove(asset);
//       });
//
//       if (_media.isEmpty) {
//         widget.onDelete?.call();
//         WidgetsBinding.instance.addPostFrameCallback((_) {
//           Navigator.of(context).pop();
//         });
//       }
//     } catch (e) {
//       print('Error deleting image: $e');
//     }
//   }
//
//   Future<void> _refreshMedia() async {
//     setState(() {
//       _isLoading = true;
//     });
//     await _loadMedia();
//     setState(() {
//       _isLoading = false;
//     });
//   }
//
//   @override
//   void dispose() {
//     _scrollController.removeListener(_onScroll);
//     _scrollController.dispose();
//     super.dispose();
//   }
//
//   // ignore: unused_field
//   Map<AssetEntity, MediaFile> _assetToMediaFileMap = {};
//
//   Future<void> _loadMedia() async {
//     try {
//       final int assetCount = await widget.album.assetCountAsync;
//       final end = (_loadedAssets + _batchSize > assetCount)
//           ? assetCount
//           : _loadedAssets + _batchSize;
//
//       if (_loadedAssets < assetCount) {
//         final media = await widget.album.getAssetListRange(
//           start: _loadedAssets,
//           end: end,
//         );
//
//         // Get list of hidden file paths
//         final hiddenFiles = await _getHiddenMediaPaths();
//
//         final visibleMedia = await Future.wait(
//           media.map((asset) async {
//             final file = await asset.file;
//             return file != null && !hiddenFiles.contains(file.path)
//                 ? asset
//                 : null;
//           }),
//         );
//
//         // Create MediaFile objects and map them
//         final nonNullMedia = visibleMedia.whereType<AssetEntity>().toList();
//         final mediaFiles =
//             await Future.wait(_convertAssetsToMediaFiles(nonNullMedia));
//         _assetToMediaFileMap = Map.fromIterables(nonNullMedia, mediaFiles);
//
//         setState(() {
//           _media.addAll(nonNullMedia);
//           _loadedAssets = end;
//           _isLoading = false;
//         });
//       }
//     } catch (e) {
//       print('Error loading media: $e');
//       setState(() {
//         _isLoading = false;
//       });
//     }
//   }
//
// // Example method to get hidden media file paths
// //   Future<List<String>> _getHiddenMediaPaths() async {
// //     try {
// //       final directory = await getApplicationDocumentsDirectory();
// //       final hiddenDirectory = Directory('${directory.path}/hidden_media');
// //       if (!await hiddenDirectory.exists()) {
// //         return [];
// //       }
// //
// //       final hiddenFiles = await hiddenDirectory.list().toList();
// //       return hiddenFiles.map((file) => file.path).toList();
// //     } catch (e) {
// //       print('Error retrieving hidden media paths: $e');
// //       return [];
// //     }
// //   }
//   List<Future<MediaFile>> _convertAssetsToMediaFiles(List<AssetEntity> assets) {
//     return assets.map((asset) async {
//       final file = await asset.file;
//       final filePath = file?.path ?? '';
//       return MediaFile(
//         id: asset.id,
//         path: filePath,
//         isVideo: asset.type == AssetType.video,
//       );
//     }).toList();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return LayoutBuilder(
//       builder: (context, constraints) {
//         // final Size size = Size(constraints.maxWidth, constraints.maxHeight);
//         return Scaffold(
//           appBar: AppBar(
//             title: Text(widget.album.name),
//             leading: IconButton(
//               onPressed: () {
//                 Navigator.pop(context);
//               },
//               icon: const Icon(Icons.arrow_back_ios),
//             ),
//           ),
//           body: _isLoading && _media.isEmpty
//               ? const Center(child: CircularProgressIndicator())
//               : _media.isEmpty
//                   ? const Center(child: Text('No media available'))
//                   : LayoutBuilder(
//                       builder: (context, constraints) =>
//                           DraggableScrollbar.semicircle(
//                         controller: _scrollController,
//                         child: GridView.builder(
//                           controller: _scrollController,
//                           gridDelegate:
//                               const SliverGridDelegateWithFixedCrossAxisCount(
//                             crossAxisCount: 3,
//                             crossAxisSpacing: 4.0,
//                             mainAxisSpacing: 4.0,
//                           ),
//                           itemCount: _media.length + (_isLoading ? 1 : 0),
//                           itemBuilder: (context, index) {
//                             if (index == _media.length) {
//                               return const Center(
//                                   child: CircularProgressIndicator());
//                             }
//                             final asset = _media[index];
//                             return FutureBuilder<Uint8List?>(
//                               future: asset.thumbnailDataWithSize(
//                                   const ThumbnailSize.square(200)),
//                               builder: (context, snapshot) {
//                                 if (snapshot.connectionState ==
//                                     ConnectionState.waiting) {
//                                   return const Center(
//                                       child: CircularProgressIndicator());
//                                 } else if (snapshot.hasError ||
//                                     !snapshot.hasData) {
//                                   return const Center(
//                                       child: Text('Error loading thumbnail'));
//                                 } else {
//                                   final Uint8List? thumbnail = snapshot.data;
//                                   return GestureDetector(
//                                     onTap: () =>
//                                         _openMediaViewer(context, index),
//                                     child: Container(
//                                       padding: const EdgeInsets.all(5),
//                                       decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(8),
//                                         image: thumbnail != null
//                                             ? DecorationImage(
//                                                 image: MemoryImage(thumbnail),
//                                                 fit: BoxFit.cover,
//                                               )
//                                             : null,
//                                       ),
//                                     ),
//                                   );
//                                 }
//                               },
//                             );
//                           },
//                         ),
//                       ),
//                     ),
//         );
//       },
//     );
//   }
//
//   Future<void> _openMediaViewer(BuildContext context, int index) async {
//     final mediaFiles = await Future.wait(_convertAssetsToMediaFiles(_media));
//
//     if (mediaFiles.isNotEmpty) {
//       final result = await Navigator.of(context).push(
//         MaterialPageRoute(
//           builder: (context) => MediaViewerPage(
//             initialIndex: index,
//             media: _media,
//             onImageDeleted: (mediaFile) {
//               _removeImage(_media[index]);
//             },
//             loadMedia: _refreshMedia,
//           ),
//         ),
//       );
//
//       if (result != null) {
//         _refreshMedia(); // Refresh media after deletion
//       }
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('No media available')),
//       );
//     }
//   }
// }
import 'dart:typed_data';
import 'package:draggable_scrollbar/draggable_scrollbar.dart';
import 'package:flutter/material.dart';
import 'package:gallery_app/Views/HideMedia/hide_media.dart';
import 'package:gallery_app/Widget/MediaViewerpage/media_tile.dart';
import 'package:photo_manager/photo_manager.dart';

class AlbumPage extends StatefulWidget {
  final AssetPathEntity album;
  final int initialIndex;
  final VoidCallback? onDelete;

  AlbumPage({required this.album, this.initialIndex = 0, this.onDelete});

  @override
  _AlbumPageState createState() => _AlbumPageState();
}

class _AlbumPageState extends State<AlbumPage> {
  final List<AssetEntity> _media = [];
  bool _isLoading = true;
  final ScrollController _scrollController = ScrollController();
  int _loadedAssets = 0;
  final int _batchSize = 50; // Adjust batch size based on performance

  @override
  void initState() {
    super.initState();
    _loadMedia();
    _scrollController.addListener(_onScroll);
  }

  Future<void> _loadMedia() async {
    try {
      final int assetCount = await widget.album.assetCountAsync;
      final end = (_loadedAssets + _batchSize > assetCount)
          ? assetCount
          : _loadedAssets + _batchSize;

      if (_loadedAssets < assetCount) {
        final media = await widget.album.getAssetListRange(
          start: _loadedAssets,
          end: end,
        );

        setState(() {
          _media.addAll(media);
          _loadedAssets = end;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error loading media: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
            _scrollController.position.maxScrollExtent - 200 &&
        !_isLoading) {
      _loadMoreMedia();
    }
  }

  Future<void> _loadMoreMedia() async {
    setState(() {
      _isLoading = true;
    });
    await _loadMedia();
    setState(() {
      _isLoading = false;
    });
  }

  void _removeImage(AssetEntity asset) async {
    try {
      setState(() {
        _media.remove(asset);
      });

      if (_media.isEmpty) {
        widget.onDelete?.call(); // Notify that the album is empty
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.of(context).pop(); // Navigate back to AlbumsPage
        });
      }
    } catch (e) {
      print('Error deleting image: $e');
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  List<Future<MediaFile>> _convertAssetsToMediaFiles(List<AssetEntity> assets) {
    return assets.map((asset) async {
      // Retrieve the file asynchronously
      final file = await asset.file;

      // If the file is null, provide a fallback path
      final filePath = file?.path ?? '';

      return MediaFile(
        id: asset.id,
        path: filePath,
        isVideo: asset.type == AssetType.video,
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.album.name),
        leading: IconButton(
          onPressed: () {
            setState(() {
              Navigator.pop(context, _loadMedia());
            });
          },
          icon: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: _isLoading && _media.isEmpty
          ? const Center()
          : DraggableScrollbar.semicircle(
              controller: _scrollController,
              child: GridView.builder(
                controller: _scrollController,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 4.0,
                  mainAxisSpacing: 4.0,
                ),
                itemCount: _media.length + (_isLoading ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == _media.length) {
                    return const Center();
                  }

                  final asset = _media[index];
                  return FutureBuilder<Uint8List?>(
                    future: asset
                        .thumbnailDataWithSize(const ThumbnailSize.square(200)),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center();
                      } else if (snapshot.hasError || !snapshot.hasData) {
                        return const Center(
                          child: Text('Error loading thumbnail'),
                        );
                      } else {
                        final Uint8List? thumbnail = snapshot.data;
                        return GestureDetector(
                          onTap: () => _openMediaViewer(context, index),
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                image: DecorationImage(
                                  image: MemoryImage(thumbnail!),
                                  fit: BoxFit.cover,
                                )),
                          ),
                        );
                      }
                    },
                  );
                },
              ),
            ),
    );
  }

  Future<void> _openMediaViewer(BuildContext context, int index) async {
    // Ensure that the mediaFiles list is populated correctly
    final mediaFiles = await Future.wait(_convertAssetsToMediaFiles(_media));

    if (mediaFiles.isNotEmpty) {
      // Retrieve the file directly from AssetEntity for the selected index
      final asset = _media[index];
      final file = await asset.file;

      if (file != null) {
        // final imageBytes = await file.readAsBytes();

        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => MediaViewerPage(
              initialIndex: index,
              media: mediaFiles,
              // Pass the list of MediaFile
              onImageDeleted: (mediaFile) {
                _removeImage(
                    mediaFile as AssetEntity); // Update album on image deletion
              },
              loadMedia: () {
                _loadMedia();
              },
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to load image')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No media available')),
      );
    }
  }
}
