import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:gallery_app/utils/route_utils.dart';
import 'package:url_launcher/url_launcher.dart';

class GetStartScreen extends StatefulWidget {
  const GetStartScreen({super.key});

  @override
  State<GetStartScreen> createState() => _GetStartScreenState();
}

class _GetStartScreenState extends State<GetStartScreen> {
  bool _isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/welcome_img.png',
              ),
              SizedBox(
                height: 70,
              ),
              Text(
                "Welcom to Gallery",
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Montserrat',
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 4,
              ),
              Text(
                'Effortlessly organize and showcase your\nphotos with our intuitive app.',
                style: TextStyle(
                  color: Color(0xff929292),
                  fontFamily: 'Montserrat',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.clip,
              ),
              SizedBox(
                height: 45,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _isChecked = !_isChecked;
                      });
                    },
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color:
                            _isChecked ? Color(0xffFF6C01) : Color(0xffFFFFFF),
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: Color(0xffFF6C01), width: 2.0),
                      ),
                      child: _isChecked
                          ? Icon(
                              Icons.check,
                              color: _isChecked
                                  ? Color(0xffFFFFFF)
                                  : Color(0xffFF6C01),
                              size: 15.0,
                            )
                          : null,
                    ),
                  ),
                  SizedBox(width: 15),
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'I have read and agreed to your',
                            style: TextStyle(
                              color: Color(0xff929292),
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                            ),
                          ),
                          TextSpan(
                            text: '  Terms and Service',
                            style: TextStyle(
                              color: Color(0xff000000),
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () async {
                                const url = '';
                                if (await canLaunch(url)) {
                                  await launch(url);
                                } else {
                                  throw 'Could not launch $url';
                                }
                              },
                          ),
                          TextSpan(
                            text: '  and',
                            style: TextStyle(
                              color: Color(0xff929292),
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                            ),
                          ),
                          TextSpan(
                            text: '  \nPrivacy Policy',
                            style: TextStyle(
                              color: Color(0xff000000),
                              fontFamily: 'Montserrat',
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () async {
                                const url = '';
                                if (await canLaunch(url)) {
                                  await launch(url);
                                } else {
                                  throw 'Could not launch $url';
                                }
                              },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 40),
              GestureDetector(
                onTap: () {
                  if (_isChecked) {
                    Navigator.pushNamed(context, AppRoutes.introScreen);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        behavior: SnackBarBehavior.floating,
                        content: Text(
                            'Please agree to the Terms and Privacy Policy to continue.'),
                        duration: Duration(seconds: 2),
                      ),
                    );
                  }
                  // Get.to(Intro());
                },
                child: Container(
                  height: 49,
                  width: 193,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Color(0xffC1003F),
                  ),
                  child: Center(
                    child: Text(
                      textAlign: TextAlign.center,
                      "GET STARTED",
                      style: TextStyle(
                          fontFamily: 'Montserrat',
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
