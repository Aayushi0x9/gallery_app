import 'package:flutter/material.dart';
import 'package:gallery_app/Views/AlbumsPage/albums_page.dart';
import 'package:gallery_app/Views/home_page/home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class Intro extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Delay to allow _checkIntroSeen to complete its async task before rendering
    Future.delayed(Duration.zero, () => _checkIntroSeen(context));
    return Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }

  void _checkIntroSeen(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool introSeen = prefs.getBool('intro_seen') ?? false;

    if (introSeen) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HomePage()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => IntroScreen()),
      );
    }
  }
}

class IntroScreen extends StatefulWidget {
  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  PageController _pageController = PageController();
  int _currentPage = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFFFFFF),
      body: Stack(
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: (int page) {
              setState(() {
                _currentPage = page;
              });
            },
            children: [
              buildPage(
                image: 'assets/images/intro_image2.png',
                title: "Seamless Organization",
                description:
                    "Easily categorize your photos and find what\nyou need in seconds.",
              ),
              buildPage(
                image: 'assets/images/intro_image3.png',
                title: "Smart Search",
                description:
                    "Quickly locate your favorite memories with powerful search features.",
              ),
              buildPage(
                image: 'assets/images/intro_image4.png',
                title: "Hide Photos Securely",
                description:
                    "Keep your private photos safe with our easy-to-use hiding feature.",
              ),
            ],
          ),
          Positioned(
            bottom: 80.0,
            left: 16.0,
            right: 16.0,
            child: Column(
              children: [
                GestureDetector(
                  onTap: () async {
                    if (_currentPage < 2) {
                      _pageController.nextPage(
                        duration: Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                      );
                    } else {
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      await prefs.setBool(
                          'intro_seen', true); // Set the intro as seen
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                HomePage()), // Navigate to AlbumsPage
                      );
                    }
                  },
                  child: Container(
                    height: 49,
                    width: 133,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(90),
                      color: Color(0xffC1003F),
                    ),
                    child: Center(
                      child: Text(
                        "NEXT",
                        style: TextStyle(
                            fontFamily: 'Montserrat',
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 50),
                SmoothPageIndicator(
                  controller: _pageController,
                  count: 3, // Updated to match the number of pages
                  effect: WormEffect(
                    activeDotColor: Color(0xffC1003F),
                    dotColor: Color(0xffFFE2EC),
                    dotHeight: 8.0,
                    dotWidth: 8.0,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildPage(
      {required String image,
      required String title,
      required String description}) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            image,
            height: 300,
          ),
          SizedBox(height: 40),
          Text(
            title,
            style: TextStyle(
              fontSize: 20,
              fontFamily: 'Montserrat',
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 15),
          Text(
            description,
            style: TextStyle(
              color: Color(0xff929292),
              fontFamily: 'Montserrat',
              fontWeight: FontWeight.w400,
              fontSize: 15,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
