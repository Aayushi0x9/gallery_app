import 'package:flutter/material.dart';
import 'package:gallery_app/Views/AlbumsPage/albums_page.dart';
import 'package:gallery_app/utils/Globals/globals.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  bool _showToggleButton = false;
  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = _createPages();
  }

  List<Widget> _createPages() {
    return [
      PhotosPage(),
      AlbumsPage(onToggleButtonVisibilityChanged: (visible) {
        setState(() {
          _showToggleButton = visible;
        });
      }),
      SearchPage(),
      SettingsPage(),
    ];
  }

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
      if (index == 1) {
        // Navigate to AlbumsPage
        _showToggleButton = true;
      } else {
        _showToggleButton = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const SizedBox(),
        flexibleSpace: Container(
          margin: const EdgeInsets.only(top: 30),
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              const SizedBox(width: 30),
              Image.asset(
                'assets/images/pictoria_logo.png',
                height: 29,
                width: 128,
                fit: BoxFit.contain,
              ),
            ],
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: _showToggleButton
            ? [
                IconButton(
                  icon: Icon(Globals.isGridView ? Icons.grid_view : Icons.list),
                  onPressed: () {
                    setState(() {
                      Globals.isGridView = !Globals.isGridView;
                      // Optionally, you might want to notify the AlbumsPage to reset its scroll position
                      _pages[1].resetScrollPositions();
                    });
                  },
                ),
                const SizedBox(width: 16),
              ]
            : [],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFFFFF),
              Color(0xFFFFE3EC),
            ],
          ),
        ),
        child: _pages[_currentIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: const Color(0xffFAD1E1),
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey,
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.photo),
            label: 'Photos',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.photo_album),
            label: 'Album',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
  // Dummy pages for navigation
}

class PhotosPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Photos Page'));
  }
}

// class AlbumPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return const Center(child: Text('Albumk Page'));
//   }
// }
//
class SearchPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Search Page'));
  }
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Settings Page'));
  }
}
