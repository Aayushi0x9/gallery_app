import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';

class ImagePage extends StatefulWidget {
  final Uint8List? image;
  final File? imageFile;
  final VoidCallback? onDelete;

  ImagePage({
    this.image,
    this.imageFile,
    this.onDelete,
    // required Future<Null> Function() onHide,
  });

  @override
  _ImagePageState createState() => _ImagePageState();
}

class _ImagePageState extends State<ImagePage> {
  Uint8List? _imageBytes;

  @override
  void initState() {
    super.initState();
    if (widget.image != null) {
      _imageBytes = widget.image!;
    } else if (widget.imageFile != null) {
      _imageBytes = widget.imageFile!.readAsBytesSync();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _imageBytes != null
            ? InteractiveViewer(
                child: Image.memory(
                  _imageBytes!,
                  fit: BoxFit.contain,
                ),
              )
            : const Text('No image available'),
      ),
    );
  }
}
