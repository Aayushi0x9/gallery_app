import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';

import '../../Widget/MediaViewerpage/media_tile.dart';

class MediaFile {
  final String id;
  final String path;
  final bool isVideo;

  MediaFile({
    required this.id,
    required this.path,
    required this.isVideo,
  });
}

class HiddenMediaPage extends StatefulWidget {
  @override
  _HiddenMediaPageState createState() => _HiddenMediaPageState();
}

class _HiddenMediaPageState extends State<HiddenMediaPage> {
  Future<List<File>> _fetchHiddenMedia() async {
    final directory = await getApplicationDocumentsDirectory();
    final hiddenDirectory = Directory('${directory.path}/hidden_media');

    // Check if the hidden directory exists
    if (!await hiddenDirectory.exists()) {
      return [];
    }

    final files = hiddenDirectory.listSync();

    // Filter and return only files, ignoring directories
    return files.whereType<File>().toList();
  }

  Future<List<File>>? _hiddenMediaFuture;

  @override
  void initState() {
    super.initState();
    _hiddenMediaFuture = _fetchHiddenMedia();
  }

  void _refreshMedia() {
    setState(() {
      _hiddenMediaFuture = _fetchHiddenMedia();
    });
  }

  Future<void> _handleMediaNavigation(int index) async {
    final files = await _fetchHiddenMedia();
    final mediaFiles = <MediaFile>[];

    // Get all available asset paths (albums)
    final assetPathList = await PhotoManager.getAssetPathList(
      type: RequestType.common, // Both images and videos
    );

    // Loop through each asset path (album)
    for (final assetPath in assetPathList) {
      // Get all assets (media files) in the album
      final assetCount = await assetPath.assetCountAsync;
      final assetList =
          await assetPath.getAssetListRange(start: 0, end: assetCount);

      for (final asset in assetList) {
        final file = await asset.file;

        // Compare file paths and add matching assets to mediaFiles list
        if (file != null &&
            files.any((hiddenFile) => hiddenFile.path == file.path)) {
          mediaFiles.add(
            MediaFile(
              id: asset.id,
              path: file.path,
              isVideo: asset.type == AssetType.video,
            ),
          );
        }
      }
    }

    // If no media files are found, show an error message
    if (mediaFiles.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No media found to view.')),
      );
      return; // Exit early if no media is found
    }

    // Find the MediaFile corresponding to the initial index
    final initialMediaFile = mediaFiles.isNotEmpty ? mediaFiles[index] : null;

    // Navigate to MediaViewerPage
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MediaViewerPage(
          media: mediaFiles,
          initialIndex: mediaFiles.indexOf(initialMediaFile!),
          onImageDeleted: (deletedMedia) {
            _refreshMedia(); // Refresh media list after deletion
          },
          isHiddenMedia: true,
          loadMedia: _fetchHiddenMedia,
        ),
      ),
    ).then((_) {
      _refreshMedia(); // Refresh media list after navigating back
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hidden Media'),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios),
        ),
      ),
      body: FutureBuilder<List<File>>(
        future: _hiddenMediaFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return const Center(child: Text('Error loading hidden media'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hidden media found'));
          } else {
            final files = snapshot.data!;
            return GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 4.0,
                mainAxisSpacing: 4.0,
              ),
              itemCount: files.length,
              itemBuilder: (context, index) {
                final file = files[index];
                final isVideo = file.path.endsWith('.mp4');
                return GestureDetector(
                  onTap: () async {
                    await _handleMediaNavigation(index);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      image: !isVideo
                          ? DecorationImage(
                              image: FileImage(file),
                              fit: BoxFit.cover,
                            )
                          : null,
                      color: isVideo
                          ? Colors.black
                          : null, // To indicate video files
                    ),
                    child: isVideo
                        ? const Center(
                            child: Icon(Icons.video_library,
                                color: Colors.white, size: 40),
                          )
                        : null,
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
